package base;

import org.openqa.selenium.WebDriver;

public class BaseUtil {
	public WebDriver driver;
}
