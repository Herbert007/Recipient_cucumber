package base;

public enum Browsers {firefox, chrome

}
