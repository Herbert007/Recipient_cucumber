package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.BaseUtil;

public class MemberLoginPage {
	private WebDriver driver;
	
	
	public MemberLoginPage(WebDriver driver) {
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(how = How.ID, using = "ssousername")
	public WebElement username;
	
	@FindBy(how = How.ID, using = "password")
	public WebElement password;
	
	/**
	 * 
	 */
	//@FindBy(how = How.CSS, using = "input.button")
	@FindBy(how = How.XPATH, using = "//input[@value='Login']")
	public WebElement loginButton;
	
	
	
	public void setUsername(String usern) {
		username.sendKeys(usern);
	}
	
	public void setPassword(String passw) {
		password.sendKeys(passw);
	}
	
	public void ClickOnButton() {
		loginButton.click();
	}
}

