package steps;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import base.BaseUtil;
import base.Browsers;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hook extends BaseUtil{
	private BaseUtil base;
	public static Properties p=null;
    public Hook(BaseUtil base) {
        this.base = base;
    }

    @Before
    public void InitializeTest() throws IOException{

    	p=new Properties();
		FileInputStream fi=new FileInputStream("C:\\Users\\hvandehaterd\\eclipse-workspace\\Recipient_cucumber\\src\\test\\java\\base\\global.properties");
		p.load(fi);
		System.out.println(p.getProperty("browser"));
		
		if(p.getProperty("browser").contains((Browsers.firefox.toString())))
		{
			System.setProperty("webdriver.gecko.driver","C:\\Users\\hvandehaterd\\geckodriver.exe");
			base.driver=new FirefoxDriver();
		}
		else if (p.getProperty("browser").contains(Browsers.chrome.toString()))
		{
			System.setProperty("webdriver.chrome.driver","C:\\Users\\hvandehaterd\\chromedriver.exe");
			base.driver=new ChromeDriver();
			}
		else
		{
			//Internetexplorer
		}
		
		base.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
    }

    @After
    public void TearDownTest(Scenario scenario) {
        if (scenario.isFailed()) {
            //Take screenshot logic goes here
            System.out.println(scenario.getName());
        }
        System.out.println("Closing the browser : MOCK");
    }
}
