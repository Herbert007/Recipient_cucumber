package steps;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

import base.BaseUtil;
import base.Testbase;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.MemberLoginPage;


public class LoginStep extends BaseUtil{
	
	private BaseUtil base;
	
	public LoginStep(BaseUtil base) {
		this.base = base;
	}

	WebDriver driver;
	Properties prop;
	
	
	@Given("User navigates to memberloginpage")
	public void userNavigatesToMemberLoginPage() {
		
		driver = base.driver;
		prop = Hook.p;
		driver.get(prop.getProperty("url"));
		
	}

	@When("User enters UserName and Password")
	public void userEntersUserNameAndPassword () {
		MemberLoginPage memberLoginp = new MemberLoginPage(base.driver);
		
		memberLoginp.setUsername(Hook.p.getProperty("username"));
		memberLoginp.setPassword(Hook.p.getProperty("password"));
	}
	
	@Then("User clicks on loginbutton")
	public void userClicksOnLoginButton() {
		MemberLoginPage memberLoginp = new MemberLoginPage(base.driver);
		memberLoginp.ClickOnButton();
	}
}

